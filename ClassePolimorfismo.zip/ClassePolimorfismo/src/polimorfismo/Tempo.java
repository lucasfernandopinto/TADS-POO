package polimorfismo;

public class Tempo {

    public long quantidade(){
        return 0;
    }

    public String toString(){
        return "";
    }
}
