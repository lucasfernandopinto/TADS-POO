package polimorfismo;

import java.util.Scanner;

public class TestaTempo {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Digite o tipo (tempo, data, horario):");
        String op = entrada.nextLine();
        
        Tempo tempo = null;

        switch (op) {
            case "tempo":
                tempo = new Tempo();
                break;
            case "data":
                System.out.println("Digite o dia:");
                int dia = entrada.nextInt();
                System.out.println("Digite o mês:");
                int mes = entrada.nextInt();
                System.out.println("Digite o ano:");
                int ano = entrada.nextInt();
                tempo = new Data(dia, mes, ano);
                break;
            case "horario":
                System.out.println("Digite a hora:");
                int hora = entrada.nextInt();
                System.out.println("Digite o minuto:");
                int minuto = entrada.nextInt();
                System.out.println("Digite o segundo:");
                int segundo = entrada.nextInt();
                tempo = new Horario(hora, minuto, segundo);
                break;
            default:
                System.out.println("Tipo inexistente: " + op);
                entrada.close();
                return;
        }
        
        dadosTempo(tempo);
        entrada.close();
    }

    public static void dadosTempo(Tempo oTempo) {
        System.out.println("Tempo formatado: " + oTempo.toString());
        System.out.println("Tempo em segundos: " + oTempo.quantidade());
    }
}
