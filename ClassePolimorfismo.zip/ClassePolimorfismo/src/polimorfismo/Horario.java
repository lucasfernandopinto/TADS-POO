package polimorfismo;

public class Horario extends Tempo{
    private Integer hora;
    private Integer minuto;
    private Integer segundo;

    public Horario(Integer hora, Integer minuto, Integer segundo){
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
    }

    public Horario(){

    }

    public Integer getHora() {
        return this.hora;
    }

    public void setHora(Integer hora) {
        this.hora = hora;
    }

    public Integer getMinuto() {
        return this.minuto;
    }

    public void setMinuto(Integer minuto) {
        this.minuto = minuto;
    }

    public Integer getSegundo() {
        return this.segundo;
    }

    public void setSegundo(Integer segundo) {
        this.segundo = segundo;
    }

    @Override
    public long quantidade(){
        return (hora * 3600 + minuto * 60 + segundo);
    }

    @Override
    public String toString(){
        return (hora + ":" + minuto + ":" + segundo);
    }

}
